//
//  HJPrinterDemoViewController.m
//  PrinterDemo
//
//  Created by doulai on 9/15/15.
//  Copyright (c) 2015 com.cmcc. All rights reserved.
//

#import "HJPrinterDemoViewController.h"
//#import "PrinterListViewController.h"
#import <PrinterSDK/PrinterSDK.h>
//#import "PrinterSDK.h"
@interface HJPrinterDemoViewController ()

@end

@implementation HJPrinterDemoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */
- (IBAction)print:(id)sender {
    NSString*textToPrint=@"--------大师兄公司－－－－－－－\n销售单\n 毛线衣服            1件        10元\n毛线衣服            1件        10元\n毛线衣服            1件        10元\n毛线衣服            1件        10元\n毛线衣服            1件        10元\n毛线衣服            1件        10元\n毛线衣服            1件        10元\n毛线衣服            1件        10元\n毛线衣服            1件        10元\n毛线衣服            1件        10元\n毛线衣服            1件        10元\n毛线衣服            1件        10元\n毛线衣服            1件        10元\n毛线衣服            1件        10元\n毛线衣服            1件        10元\n毛线衣服            1件        10元\n毛线衣服            1件        10元\n";
    NSString*barcode=@"www.baidu.com";//没有就不传
//    textToPrint=@"--------大师兄公司－－－－－－－\n";
    NSDictionary*dic=@{@"textToPrint":textToPrint,@"barcode":barcode};
#warning 请确保本身的navigationController是有效的
#warning 工程的General->Embedded Binaries  + PrinterSdk.framework
#warning 购买便携式打印机 请联系QQ153887715 淘宝搜索 掌上开单
    [PrinterWraper printDictionary:dic fromviewc:self printeruid:nil];
//    [PrinterWraper chooseNewPrinter:self];

    
}


@end
