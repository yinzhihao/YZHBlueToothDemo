//
//  PrinterSDK.h
//  PrinterSDK
//
//  Created by doulai on 15/9/16.
//  Copyright (c) 2015年 com.cmcc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PrinterSDK.
//FOUNDATION_EXPORT double PrinterSDKVersionNumber;
//
////! Project version string for PrinterSDK.
//FOUNDATION_EXPORT const unsigned char PrinterSDKVersionString[];




//封装的打印
@interface PrinterWraper : NSObject
//打印内容

/*
 dic=@{@"textToPrint":textToPrint,@"barcode":barcode};
 sender 用来打开蓝牙选择列表，如果是首次打印请确保本身的navigationController是有效的
 uid 指定打印机  nil
 */
+(BOOL)printDictionary:(NSDictionary*)dic fromviewc:(UIViewController*)sender printeruid:(NSString*)uid;

//选择新的打印机  请确保本身的navigationController是有效的
+(void)chooseNewPrinter:(UIViewController*)sender;
@end


