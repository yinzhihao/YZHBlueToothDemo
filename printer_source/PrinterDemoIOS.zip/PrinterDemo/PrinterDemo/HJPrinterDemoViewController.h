//
//  HJPrinterDemoViewController.h
//  PrinterDemo
//
//  Created by doulai on 9/15/15.
//  Copyright (c) 2015 com.cmcc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HJPrinterDemoViewController : UIViewController

@end
