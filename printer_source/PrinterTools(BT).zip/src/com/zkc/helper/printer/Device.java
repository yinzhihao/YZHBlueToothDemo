package com.zkc.helper.printer;

public class Device {
	public String deviceName;
	public String deviceAddress;
}
