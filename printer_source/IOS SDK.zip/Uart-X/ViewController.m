//
//  ViewController.m
//  Uart-X
//
//  Created by xu jason on 12-12-14.
//  Copyright (c) 2012年 xu jason(jasonxu@vbenz.com). All rights reserved.
//

#import "ViewController.h"
#import "uartLib.h"

#define MAX_CHARACTERISTIC_VALUE_SIZE 20

@interface ViewController ()<UITextViewDelegate>{
    UartLib *uartLib;

    CBPeripheral	*connectPeripheral;
    
    NSMutableArray      *sendDataArray;
}

@end

@implementation ViewController
@synthesize peripheralName;
@synthesize sendDataView;
@synthesize recvDataView;
@synthesize sendButton;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.view setBackgroundColor:[UIColor groupTableViewBackgroundColor]];
    
    connectPeripheral = nil;
    
    uartLib = [[UartLib alloc] init];
    
    [uartLib setUartDelegate:self];
    
    sendDataArray = [[NSMutableArray alloc] init];
    
    [[self sendButton] setEnabled:FALSE];
	// Do any additional setup after loading the view, typically from a nib.
    
    [NSTimer scheduledTimerWithTimeInterval:(float)0.02 target:self selector:@selector(sendDataTimer:) userInfo:nil repeats:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)scanStart:(id)sender{
    [uartLib scanStart];
}

- (IBAction)scanStop:(id)sender{
    [uartLib scanStop];
}

- (IBAction)connect:(id)sender{
    NSLog(@"connect Peripheral");
    [uartLib scanStop];
    [uartLib connectPeripheral:connectPeripheral];
}

- (IBAction)Disconnect:(id)sender{
    [uartLib scanStop];
    [uartLib disconnectPeripheral:connectPeripheral];
}

- (IBAction)sendData:(id)sender{
    NSString *curPrintContent;
    curPrintContent = [sendDataView text];
    
    if ([curPrintContent length]) {
        NSString *printed = [curPrintContent stringByAppendingFormat:@"%c%c%c%c", '\n', '\n', '\n', '\n'];
        
        [self printerWithFormat:Align_Right CharZoom:Char_Zoom_3 Content:printed];
        [self.sendDataView resignFirstResponder];
    }
}


- (IBAction)printInput:(id)sender{
    [self printerInit];
    
    [self printerWithFormat:Align_Center CharZoom:Char_Zoom_2 Content:@"澄泓餐饮排号单\n"];
    
    [self printerWithFormat:Align_Left CharZoom:Char_Normal Content:@"\n本店活动：国庆来本店消费满100元送100元代金券，最新活动，尽情期待......\n"];
    
    [self printerWithFormat:Align_Center CharZoom:Char_Zoom_2 Content:@"\n中桌2号\n\n"];
    
    [self printerWithFormat:Align_Center CharZoom:Char_Normal Content:@"您是第2号，您前面还有1桌客人在排队\n\n"];
    
        //[self printTwoDimenCode:@"www.sina.com"];
    [self printTwoDimenCode:@"http://www.69uu.cn"];
    
        //[self printerWithFormat:Align_Center CharZoom:Char_Normal Content:@"\r\n立即扫描二维码\r\n用［帮帮排APP］帮你排队哟\r\n－－－－－－－－－－－－－－－－－－－－－－－\r\n用‘帮帮排’APP帮你排队，我们会提前5个号通知您，请您准时前往就餐\r\n注：本票过号15分钟后失效\r\n\r\n桌位类型：中桌\r\n取票时间：2013－09－08 17：50：08\r\n门店地址：上海市\r\n电话：021－12345678\r\n－－－－－－－－－－－－－－－－－－－－－－－\r\n注：活动最终解释权归商家所有\r\n"];
        //return;
    [self printerWithFormat:Align_Center CharZoom:Char_Normal Content:@"\n立即扫描二维码\n"];
    
    [self printerWithFormat:Align_Center CharZoom:Char_Normal Content:@"用［帮帮排APP］帮你排队哟\n"];
    
    [self printerWithFormat:Align_Left CharZoom:Char_Normal Content:@"－－－－－－－－－－－－－－－－－－－－－－－\n"];
    
    [self printerWithFormat:Align_Left CharZoom:Char_Normal Content:@"用‘帮帮排’APP帮你排队，我们会提前5个号通知您，请您准时前往就餐\n"];
    
    [self printerWithFormat:Align_Left CharZoom:Char_Normal Content:@"注：本票过号15分钟后失效\n\n"];
    
    [self printerWithFormat:Align_Left CharZoom:Char_Normal Content:@"桌位类型：中桌\n"];
    
    [self printerWithFormat:Align_Left CharZoom:Char_Normal Content:@"取票时间：2013－09－08 17：50：08\n"];
    
    [self printerWithFormat:Align_Left CharZoom:Char_Normal Content:@"门店地址：上海市\n"];
    
    [self printerWithFormat:Align_Left CharZoom:Char_Normal Content:@"电话：021－12345678\n"];
    
    [self printerWithFormat:Align_Left CharZoom:Char_Normal Content:@"－－－－－－－－－－－－－－－－－－－－－－－\n"];
    
    [self printerWithFormat:Align_Left CharZoom:Char_Normal Content:@"注：活动最终解释权归商家所有\n"];
    
    [self cutPaper];
    [self printerInit];
        //[self printerWithFormat:Align_Left CharZoom:Char_Normal Content:@"\n"];
}


#pragma mark -
#pragma mark printer func

- (void) sendDataTimer:(NSTimer *)timer {
        //NSLog(@"send data timer");
    
    if ([sendDataArray count] > 0) {
        NSData* cmdData;
        
        cmdData = [sendDataArray objectAtIndex:0];
        
        [uartLib sendValue:connectPeripheral sendData:cmdData type:CBCharacteristicWriteWithResponse];
        
        [sendDataArray removeObjectAtIndex:0];
    }
    
    
    /*
    NSInteger nCount;
    
    nCount = [sendDataArray count];
    if (nCount == 0) {
        return;
    }
    
    if (nCount > 3) {
        nCount = 3;
    }
    for (int i = 0; i<nCount; i++) {
        NSData* cmdData;
 
        cmdData = [sendDataArray objectAtIndex:0];
        
        [uartLib sendValue:connectPeripheral sendData:cmdData type:CBCharacteristicWriteWithoutResponse];
        
        [sendDataArray removeObjectAtIndex:0];
    }
    */
}

- (void) printerWithFormat:(Align_Type_e)eAlignType CharZoom:(Char_Zoom_Num_e)eCharZoomNum Content:(NSString *)printContent{
    NSData  *data	= nil;
    NSUInteger strLength;
   
    NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
        //NSData *data = [curPrintContent dataUsingEncoding:enc];
        //NSLog(@"dd:%@", data);
        //NSString *retStr = [[NSString alloc] initWithData:data encoding:enc];
        //NSLog(@"str:%@", retStr);
    

    Byte caPrintFmt[500];
    
    /*初始化命令：ESC @ 即0x1b,0x40*/
        //caPrintFmt[0] = 0x1b;
        //caPrintFmt[1] = 0x40;
    
    /*字符设置命令：ESC ! n即0x1b,0x21,n*/
    caPrintFmt[0] = 0x1d;
    caPrintFmt[1] = 0x21;
    
    caPrintFmt[2] = (eCharZoomNum<<4) | eCharZoomNum;
    
    caPrintFmt[3] = 0x1b;
    caPrintFmt[4] = 0x61;
    caPrintFmt[5] = eAlignType;
    

    NSData *printData = [printContent dataUsingEncoding: enc];
    Byte *printByte = (Byte *)[printData bytes];
    
    strLength = [printData length];
    if (strLength < 1) {
        return;
    }
    
    for (int  i = 0; i<strLength; i++) {
        caPrintFmt[6+i] = *(printByte+i);
    }
    
    data = [NSData dataWithBytes:caPrintFmt length:6+strLength];
    
    [self printLongData:data];
}


- (void) printLongData:(NSData *)printContent{
    NSUInteger i;
    NSUInteger strLength;
    NSUInteger cellCount;
    NSUInteger cellMin;
    NSUInteger cellLen;
    
    strLength = [printContent length];
    if (strLength < 1) {
        return;
    }
    
    cellCount = (strLength%MAX_CHARACTERISTIC_VALUE_SIZE)?(strLength/MAX_CHARACTERISTIC_VALUE_SIZE + 1):(strLength/MAX_CHARACTERISTIC_VALUE_SIZE);
    for (i=0; i<cellCount; i++) {
        cellMin = i*MAX_CHARACTERISTIC_VALUE_SIZE;
        if (cellMin + MAX_CHARACTERISTIC_VALUE_SIZE > strLength) {
            cellLen = strLength-cellMin;
        }
        else {
            cellLen = MAX_CHARACTERISTIC_VALUE_SIZE;
        }
        
        NSLog(@"print:%d,%d,%d,%d", strLength,cellCount, cellMin, cellLen);
        NSRange rang = NSMakeRange(cellMin, cellLen);
        NSData *subData = [printContent subdataWithRange:rang];

        NSLog(@"print:%@", subData);
            //data = [strRang dataUsingEncoding: NSUTF8StringEncoding];
            //NSLog(@"print:%@", data);
        
        [sendDataArray addObject:subData];        
    }
}

- (void) printerInit{
    NSData *printFormat;
    Byte caPrintFmt[20];
    
    caPrintFmt[0] = 0x1b;
    caPrintFmt[1] = 0x40;
    
        //caPrintFmt[] = ;
        //caPrintFmt[] = ;
    printFormat = [NSData dataWithBytes:caPrintFmt length:2];
    NSLog(@"format:%@", printFormat);
    
    [sendDataArray addObject:printFormat];
    
}

- (void) cutPaper{
    NSData *printFormat;
    Byte caPrintFmt[20];
    
    caPrintFmt[0] = 0x1d;
    caPrintFmt[1] = 0x56;
    caPrintFmt[2] = 0x42;
    caPrintFmt[3] = 0x20;
        //caPrintFmt[] = ;
        //caPrintFmt[] = ;
    printFormat = [NSData dataWithBytes:caPrintFmt length:4];
    NSLog(@"format:%@", printFormat);
    
    [sendDataArray addObject:printFormat];
    
}

- (void) printTwoDimenCode:(NSString *)printContent{
    NSData *printFormat;
    Byte caPrintFmt[500];

    caPrintFmt[0] = 0x1b;
    caPrintFmt[1] = 0x40;
    
    caPrintFmt[2] = 0x1d;
    caPrintFmt[3] = 0x28;
    
    caPrintFmt[4] = 0x6b;
    
    caPrintFmt[5] = 0x03;
    caPrintFmt[6] = 0x00;
    caPrintFmt[7] = 0x31;
    caPrintFmt[8] = 0x43;
    caPrintFmt[9] = 0x08;

    
    caPrintFmt[10] = 0x1d;
    caPrintFmt[11] = 0x28;
    
    caPrintFmt[12] = 0x6b;
    
    caPrintFmt[13] = 0x03;
    caPrintFmt[14] = 0x00;
    caPrintFmt[15] = 0x31;
    caPrintFmt[16] = 0x45;
    caPrintFmt[17] = 0x30;
    
        //caPrintFmt[] = ;
        //caPrintFmt[] = ;
    printFormat = [NSData dataWithBytes:caPrintFmt length:18];
    NSLog(@"format:%@", printFormat);
    
    [sendDataArray addObject:printFormat];
    
    
    
    NSInteger nLength = [printContent length];
    nLength += 3;
    
    caPrintFmt[0] = 0x1d;
    caPrintFmt[1] = 0x28;
    
    caPrintFmt[2] = 0x6b;
    
    caPrintFmt[3] = nLength & 0xFF;
    caPrintFmt[4] = (nLength >> 8) & 0xFF;
    caPrintFmt[5] = 0x31;
    caPrintFmt[6] = 0x50;
    caPrintFmt[7] = 0x30;
    
    
    NSData *printData = [printContent dataUsingEncoding: NSASCIIStringEncoding];
    Byte *printByte = (Byte *)[printData bytes];
    
    nLength -= 3;
    for (int  i = 0; i<nLength; i++) {
        caPrintFmt[8+i] = *(printByte+i);
    }
    
    printFormat = [NSData dataWithBytes:caPrintFmt length:nLength+8];
    
    NSLog(@"format:%@", printFormat);
    
    [self printLongData:printFormat];
        //[sendDataArray addObject:printFormat];
    
    
    
    caPrintFmt[0] = 0x1b;
    caPrintFmt[1] = 0x61;
    
    caPrintFmt[2] = 0x01;
    
    
    
    caPrintFmt[3] = 0x1d;
    caPrintFmt[4] = 0x28;
    
    caPrintFmt[5] = 0x6b;
    
    caPrintFmt[6] = 0x03;
    caPrintFmt[7] = 0x00;
    caPrintFmt[8] = 0x31;
    caPrintFmt[9] = 0x52;
    caPrintFmt[10] = 0x30;
    
    
    caPrintFmt[11] = 0x1d;
    caPrintFmt[12] = 0x28;
    
    caPrintFmt[13] = 0x6b;
    
    caPrintFmt[14] = 0x03;
    caPrintFmt[15] = 0x00;
    caPrintFmt[16] = 0x31;
    caPrintFmt[17] = 0x51;
    caPrintFmt[18] = 0x30;
    
        //caPrintFmt[] = ;
        //caPrintFmt[] = ;
    printFormat = [NSData dataWithBytes:caPrintFmt length:19];
    NSLog(@"format:%@", printFormat);
    
    [sendDataArray addObject:printFormat];
    
    
    caPrintFmt[0] = 0x1b;
    caPrintFmt[1] = 0x40;
    
        //caPrintFmt[] = ;
        //caPrintFmt[] = ;
    printFormat = [NSData dataWithBytes:caPrintFmt length:2];
    NSLog(@"format:%@", printFormat);
    
    [sendDataArray addObject:printFormat];
}



#pragma mark -
#pragma mark UartDelegate
/****************************************************************************/
/*                       UartDelegate Methods                        */
/****************************************************************************/
- (void) didBluetoothPoweredOff{
    NSLog(@"power off");
}

- (void) didScanedPeripherals:(NSMutableArray  *)foundPeripherals
{
    NSLog(@"didScanedPeripherals(%d)", [foundPeripherals count]);
    
    CBPeripheral	*peripheral;
    
    for (peripheral in foundPeripherals) {
		NSLog(@"--Peripheral:%@", [peripheral name]);
	}
    
    if ([foundPeripherals count] > 0) {
        connectPeripheral = [foundPeripherals objectAtIndex:0];
        if ([connectPeripheral name] == nil) {
            [[self peripheralName] setText:@"BTCOM"];
        }else{
            [[self peripheralName] setText:[connectPeripheral name]];
        }
    }else{
            [[self peripheralName] setText:nil];
            //connectPeripheral = nil;
    }
}

- (void) didConnectPeripheral:(CBPeripheral *)peripheral{
    NSLog(@"did Connect Peripheral");
    
    connectPeripheral = peripheral;
    [[self sendButton] setEnabled:TRUE];
}

- (void) didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    NSLog(@"did Disconnect Peripheral");
    
    [[self sendButton] setEnabled:FALSE];
    [[self peripheralName] setText:@""];
    connectPeripheral = nil;
}

- (void) didWriteData:(CBPeripheral *)peripheral error:(NSError *)error{
    NSLog(@"didWriteData:%@", [peripheral name]);
}

- (void) didReceiveData:(CBPeripheral *)peripheral recvData:(NSData *)recvData
{
    NSLog(@"uart recv(%d):%@", [recvData length], recvData);
}


- (void) didRecvRSSI:(CBPeripheral *)peripheral RSSI:(NSNumber *)RSSI{
    
}


#pragma mark -
#pragma mark UITextViewDelegate
-(BOOL)textFieldShouldReturn:(UITextField *)textField

{
    [textField resignFirstResponder];
    
    return YES;
}
@end
