//
//  AppDelegate.h
//  Uart-X
//
//  Created by xu jason on 12-12-14.
//  Copyright (c) 2012年 xu jason(jasonxu@vbenz.com). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
