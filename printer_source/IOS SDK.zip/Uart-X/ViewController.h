//
//  ViewController.h
//  Uart-X
//
//  Created by xu jason on 12-12-14.
//  Copyright (c) 2012年 xu jason(jasonxu@vbenz.com). All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UartLib.h"

typedef  enum {
    Align_Left = 0X00,
    Align_Center,
    Align_Right,
}Align_Type_e;

typedef  enum {
    Char_Normal = 0X00,
    Char_Zoom_2,
    Char_Zoom_3,
    Char_Zoom_4
}Char_Zoom_Num_e;

@interface ViewController : UIViewController <UartDelegate>

@property (readonly, nonatomic) IBOutlet UITextView *recvDataView;

@property (weak, nonatomic) IBOutlet UILabel *peripheralName;

@property (weak, nonatomic) IBOutlet UITextField *sendDataView;
@property (nonatomic, retain) IBOutlet UIButton *sendButton;

- (IBAction)scanStart:(id)sender;

- (IBAction)scanStop:(id)sender;

- (IBAction)connect:(id)sender;

- (IBAction)Disconnect:(id)sender;

- (IBAction)sendData:(id)sender;

- (IBAction)printInput:(id)sender;
@end
